# Nestor Ingles Jr
# CSC 121 001

def feet_to_inches(feet):
    return feet * 12

def main():
    inches = float(input('Enter an ammount of feet to convert to inches:'))
    print(feet_to_inches(inches), "inches")
    

main()
