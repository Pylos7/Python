tuition = 8000
tuition = (tuition * 1.03)
print('In 1 year, the tuition will be $' + str(format(tuition, ',.2f')) + '.')
for count in range (2, 6):
    tuition = (tuition * 1.03)
    print('In ' + str(count) + ' years, the tuition will be $' + str(format(tuition, ',.2f')) + '.')
